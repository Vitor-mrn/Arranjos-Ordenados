import java.util.Random;

public class ExperimentoExclusao {

    static final int EXECUCOES = 100;
    static final int TAM = 100000;

    public static void main(String[] args) {

        long[] tempos = new long[EXECUCOES];
        Random rand = new Random();

        for (int e = 0; e < EXECUCOES; e++) {

            ArranjoOrdenado arr = new ArranjoOrdenado(TAM, true);
            int[] numeros = new int[TAM];

            for (int i = 0; i < TAM; i++) {
                int n = rand.nextInt();
                numeros[i] = n;
                arr.inserir(n);
            }

            long t1 = System.nanoTime();

            for (int i = 0; i < TAM; i++) {
                arr.excluir(numeros[i]);
            }

            long t2 = System.nanoTime();

            tempos[e] = t2 - t1;
        }

        calcularEstatisticas(tempos);
    }

    static void calcularEstatisticas(long[] tempos) {

        double soma = 0;

        for (long t : tempos)
            soma += t;

        double media = soma / tempos.length;

        double variancia = 0;

        for (long t : tempos)
            variancia += Math.pow(t - media, 2);

        variancia /= tempos.length;

        double desvio = Math.sqrt(variancia);

        System.out.println("Media: " + media);
        System.out.println("Desvio: " + desvio);
    }
}