import java.util.Random;

public class Insercao {

    static final int EXECUCOES = 100;
    static final int TAM = 10000;

    public static void main(String[] args) {

        System.out.println("===== TESTE INSERÇÃO =====");

        testarInsercaoCrescente();
        testarInsercaoDecrescente();
        testarInsercaoAleatoria();

    }

    static void testarInsercaoCrescente() {

        long[] tempos = new long[EXECUCOES];

        for (int e = 0; e < EXECUCOES; e++) {

            ArranjoOrdenado arr = new ArranjoOrdenado(TAM, true);

            long t1 = System.nanoTime();

            for (int i = 0; i < TAM; i++) {
                arr.inserir(i);
            }

            long t2 = System.nanoTime();

            tempos[e] = t2 - t1;
        }

        imprimirResultados("Inserção Crescente", tempos);
    }

    static void testarInsercaoDecrescente() {

        long[] tempos = new long[EXECUCOES];

        for (int e = 0; e < EXECUCOES; e++) {

            ArranjoOrdenado arr = new ArranjoOrdenado(TAM, true);

            long t1 = System.nanoTime();

            for (int i = TAM; i > 0; i--) {
                arr.inserir(i);
            }

            long t2 = System.nanoTime();

            tempos[e] = t2 - t1;
        }

        imprimirResultados("Inserção Decrescente", tempos);
    }

    static void testarInsercaoAleatoria() {

        long[] tempos = new long[EXECUCOES];
        Random rand = new Random();

        for (int e = 0; e < EXECUCOES; e++) {

            ArranjoOrdenado arr = new ArranjoOrdenado(TAM, true);

            long t1 = System.nanoTime();

            for (int i = 0; i < TAM; i++) {
                arr.inserir(rand.nextInt());
            }

            long t2 = System.nanoTime();

            tempos[e] = t2 - t1;
        }

        imprimirResultados("Inserção Aleatória", tempos);
    }

    static void imprimirResultados(String nomeTeste, long[] tempos) {

        double soma = 0;

        for (long t : tempos) {
            soma += t;
        }

        double media = soma / tempos.length;

        double variancia = 0;

        for (long t : tempos) {
            variancia += Math.pow(t - media, 2);
        }

        variancia /= tempos.length;

        double desvio = Math.sqrt(variancia);

        System.out.println(nomeTeste);
        System.out.println("Tempo médio: " + media);
        System.out.println("Desvio padrão: " + desvio);
        System.out.println("---------------------------");
    }
}