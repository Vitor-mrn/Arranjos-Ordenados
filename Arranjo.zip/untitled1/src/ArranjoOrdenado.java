public class ArranjoOrdenado {

    private int[] arr;
    private int tamanho;
    private boolean crescente;

    public ArranjoOrdenado(int capacidade, boolean crescente) {
        arr = new int[capacidade];
        tamanho = 0;
        this.crescente = crescente;
    }

    public int tamanho() {
        return tamanho;
    }

    public void inserir(int valor) {

        int i;

        if (crescente) {

            for (i = tamanho - 1; i >= 0 && arr[i] > valor; i--) {
                arr[i + 1] = arr[i];
            }

        } else {

            for (i = tamanho - 1; i >= 0 && arr[i] < valor; i--) {
                arr[i + 1] = arr[i];
            }

        }

        arr[i + 1] = valor;
        tamanho++;
    }

    public boolean excluir(int valor) {

        int index = buscar(valor);

        if (index == -1)
            return false;

        for (int i = index; i < tamanho - 1; i++) {
            arr[i] = arr[i + 1];
        }

        tamanho--;
        return true;
    }

    public int buscar(int valor) {

        for (int i = 0; i < tamanho; i++) {
            if (arr[i] == valor)
                return i;
        }

        return -1;
    }

    public int get(int index) {
        return arr[index];
    }

}