import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ArranjoOrdenadoTest {

    @Test
    public void testeInsercaoCrescente() {

        ArranjoOrdenado arr = new ArranjoOrdenado(10, true);

        arr.inserir(5);
        arr.inserir(1);
        arr.inserir(3);

        assertEquals(1, arr.get(0));
        assertEquals(3, arr.get(1));
        assertEquals(5, arr.get(2));
    }

    @Test
    public void testeInsercaoDecrescente() {

        ArranjoOrdenado arr = new ArranjoOrdenado(10, false);

        arr.inserir(5);
        arr.inserir(1);
        arr.inserir(3);

        assertEquals(5, arr.get(0));
        assertEquals(3, arr.get(1));
        assertEquals(1, arr.get(2));
    }

    @Test
    public void testeExclusao() {

        ArranjoOrdenado arr = new ArranjoOrdenado(10, true);

        arr.inserir(1);
        arr.inserir(2);
        arr.inserir(3);

        arr.excluir(2);

        assertEquals(2, arr.tamanho());
        assertEquals(1, arr.get(0));
        assertEquals(3, arr.get(1));
    }
}